export const POSES = [
  { key: 'yoga1', label: 'Собака мордой вниз' },
  { key: 'yoga2', label: 'Поза посоха на четырёх опорах' },
  { key: 'yoga3', label: 'Поза стула' },
  { key: 'yoga4', label: 'Поза воина II' },
  { key: 'yoga5', label: 'Поза треугольника' },
  { key: 'yoga6', label: 'Поза вытянутого угла' },
];
